import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import mongoose from "mongoose";
import morgan from "morgan";
import http from "http";
import { Server } from "socket.io";
import connectDB from "./src/config/db.js";
import { socketAuth } from "./src/middlewares/socketAuth.js";

// Route imports
import authRoutes from "./src/routes/authRoutes.js";
import complaintRoutes from "./src/routes/complaintRoutes.js";
import adminRoutes from "./src/routes/adminRoutes.js";

dotenv.config();

const app = express();
const server = http.createServer(app);

// ✅ MUST be before routes & JSON middleware
app.use(
  cors({
    origin: "https://mtm-cms-frontend.vercel.app",
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  })
);

// ✅ Handle preflight requests
app.options("*", cors());

// Middlewares
app.use(express.json());
app.use(morgan("dev"));

// ✅ Socket Server
export const io = new Server(server, {
  cors: {
    origin: "https://mtm-cms-frontend.vercel.app",
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  },
});

io.use(socketAuth);

const onlineUsers = new Map();

// ✅ Socket.IO Events
io.on("connection", (socket) => {
  console.log("Socket connected:", socket.id);

  const userId = socket.handshake.query.userId;

  if (userId) {
    onlineUsers.set(userId, socket.id);
    io.emit("onlineUsers", Array.from(onlineUsers.keys()));
    console.log("User Online:", userId);
  }

  socket.on("joinRoom", (room) => {
    socket.join(room);
  });

  socket.on("typing", (data) => {
    io.to(data.room).emit("typing", data);
  });

  socket.on("newMessage", (data) => {
    console.log("New message received:", data);
    io.to(data.room).emit("newMessage", data.message);
  });

  socket.on("disconnect", () => {
    onlineUsers.forEach((value, key) => {
      if (value === socket.id) {
        onlineUsers.delete(key);
        io.emit("onlineUsers", Array.from(onlineUsers.keys()));
        console.log("User Offline:", key);
      }
    });

    console.log("Socket disconnected:", socket.id);
  });
});

// Routes
app.get("/", (req, res) => {
  res.send("Complaint Management System API is running 🚀");
});

app.use("/api/auth", authRoutes);
app.use("/api/complaints", complaintRoutes);
app.use("/api/admin", adminRoutes);

app.use(notFound);
app.use(errorHandler);

app.get("/api/test", (req, res) => {
  res.send("Proxy Working ✅");
});

const PORT = process.env.PORT || 3000;

connectDB().then(() => {
  server.listen(PORT, () => {
    // ✅ FIXED!
    console.log(`🌐 Server with socket.io running on port ${PORT}`);
  });
});
